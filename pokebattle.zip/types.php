<?php
class EnergyType
{
    public const FIRE = 'fire';
    public const GRASS = 'grass';
    public const LIGHTNING = 'lighting';
    public const PSYCHIC = 'psychic';
    public const FIGHTING = 'fighting';
    public const DARKNESS = 'darkness';
    public const METAL = 'matal';
    public const FAIRY = 'fairy';
    public const WATER = 'water';
}
